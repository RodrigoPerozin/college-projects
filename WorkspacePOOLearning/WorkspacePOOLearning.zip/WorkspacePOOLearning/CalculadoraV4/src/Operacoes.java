
public class Operacoes {

	
	
}
