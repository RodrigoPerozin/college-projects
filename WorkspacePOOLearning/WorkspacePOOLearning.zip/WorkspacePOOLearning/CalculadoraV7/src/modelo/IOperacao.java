package modelo;

public interface IOperacao {

	public void setNum1 (double num1);
	public void setNum2 (double num2);
	public double calcula();
	
}
