package modelo;

public class Divisao extends Operacoes {
	
	public double calcula() {
		
		double divi = num1 / num2;
		
		return divi;
	}
	
}
