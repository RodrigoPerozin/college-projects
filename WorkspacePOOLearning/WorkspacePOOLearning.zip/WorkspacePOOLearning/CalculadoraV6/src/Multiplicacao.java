
public class Multiplicacao extends Operacoes {
	
	public double calcula() {
		
		double mult = num1 * num2;
		
		return mult;
	}
	
}
